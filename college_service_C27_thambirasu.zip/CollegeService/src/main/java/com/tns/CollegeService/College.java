package com.tns.CollegeService;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class College {

		@Id
		@Column(name="collegeID")
		private int collegeID;
		
		@Column(name="name")
		private String name;
		
		@Column(name="location")
		private String location;
		
		@Column(name="dean")
		private String dean;
		
		@Column(name="establishedYear")
		private long establishedYear;

		public int getCollegeID() {
			return collegeID;
		}

		public void setCollegeID(int collegeID) {
			this.collegeID = collegeID;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getDean() {
			return dean;
		}

		public void setDean(String dean) {
			this.dean = dean;
		}

		public long getEstablishedYear() {
			return establishedYear;
		}

		public void setEstablishedYear(long establishedYear) {
			this.establishedYear = establishedYear;
		}

		public College() {
			super();
			// TODO Auto-generated constructor stub
		}

		public College(int collegeID, String name, String location, String dean, long establishedYear) {
			super();
			this.collegeID = collegeID;
			this.name = name;
			this.location = location;
			this.dean = dean;
			this.establishedYear = establishedYear;
		}

		@Override
		public String toString() {
			return "College [collegeID=" + collegeID + ", name=" + name + ", location=" + location + ", dean=" + dean
					+ ", establishedYear=" + establishedYear + "]";
		}
		
		
		
}
